# GhostDNS

This repository doesn't contain my code. I have uploaded it to GitHub for those want to analyse the code.

WARNING: This is malware...don't touch if you don't know what you are doing.

Archiving Files from:

GhostDNS: Google Cache of https://goldenkash.com
Extra Remote DNS Changing Exploits: https://packetstormsecurity.com/files/authors/7086/page2/ and www.exploitdb.com
